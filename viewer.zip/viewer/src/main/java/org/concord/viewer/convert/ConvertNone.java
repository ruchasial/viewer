package org.concord.viewer.convert;

public class ConvertNone implements ConvertFile {

	public String convert(String inputPath ,String fileName) {
		// TODO Auto-generated method stub
		return outputPath;
	}
	public void display (String outputPath)
	{
		
		
	}

}